package com.example.packup_podejscie_3.data.dto

import com.example.packup_podejscie_3.domain.model.Ankiety
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import java.util.UUID

@Serializable
data class AnkietyDto(
    @SerialName("ID")
    val id: String? = null,

    @SerialName("Pytanie")
    val pytanie: String,

    @SerialName("WydarzenieUUID")
    val wydarzenieId: String
)
