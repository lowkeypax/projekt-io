package com.example.packup_podejscie_3.domain.repository

import com.example.packup_podejscie_3.data.dto.RolaUczestnikaDto
import com.example.packup_podejscie_3.domain.model.RolaUczestnika

interface Rola_uczestnikaRepository {
    suspend fun createRola_uczestnika(rolaUczestnika: RolaUczestnika): Boolean
    suspend fun getRole_uczestnikow(wydarzenieId: String): List<RolaUczestnikaDto>
    suspend fun getRola_uczestnika(userId: String, wydarzenieId: String): RolaUczestnikaDto
    suspend fun deleteRola_uczestnika(userId: String, wydarzenieId: String)
    suspend fun updateRola_uczestnika(
        userId: String, rola: String, wydarzenieId: String
    )
}