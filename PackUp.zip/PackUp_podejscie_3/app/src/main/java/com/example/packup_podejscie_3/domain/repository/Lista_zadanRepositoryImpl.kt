package com.example.packup_podejscie_3.domain.repository

import com.example.packup_podejscie_3.data.dto.Lista_zadanDto
import com.example.packup_podejscie_3.domain.model.Lista_zadan
import io.github.jan.supabase.postgrest.Postgrest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.lang.Exception
import javax.inject.Inject

class Lista_zadanRepositoryImpl @Inject constructor(
    private val postgrest: Postgrest
) : Lista_zadanRepository {
    override suspend fun createZadanie(lista_zadan: Lista_zadan): Boolean {
        return try{
            withContext(Dispatchers.IO) {
                val lista_zadanDto = Lista_zadanDto(
                    nazwa = lista_zadan.nazwa,
                    wydarzenieId = lista_zadan.wydarzenieId,
                    userId = lista_zadan.userId,
                    czyWykonano = false,
                    opis = lista_zadan.opis
                )
                postgrest.from("lista_zadan").insert(lista_zadanDto)
                true
            }
            true
        } catch (e: Exception){
            throw e
        }
    }

    override suspend fun getLista_zadan(wydarzenieId: String): List<Lista_zadanDto> {
        return withContext(Dispatchers.IO){
            postgrest.from("lista_zadan").select {
                filter {
                    eq("wydarzenieuuid", wydarzenieId)
                }
            }.decodeList<Lista_zadanDto>()

        }
    }

    override suspend fun getZadanie(nazwa: String, wydarzenieId: String, userId: String): Lista_zadanDto {
        return withContext(Dispatchers.IO){
            postgrest.from("lista_zadan").select {
                filter {
                    and {
                        eq("nazwa_zadania", nazwa)
                        eq("wydarzenieuuid", wydarzenieId)
                        eq("user_id", userId)
                    }
                }
            }.decodeSingle<Lista_zadanDto>()
        }
    }

    override suspend fun deleteZadanie(nazwa: String, wydarzenieId: String, userId: String) {
        return withContext(Dispatchers.IO){
            postgrest.from("lista_zadan").delete {
                filter {
                    and {
                        eq("nazwa_zadania", nazwa)
                        eq("wydarzenieuuid", wydarzenieId)
                        eq("user_id", userId)
                    }
                }
            }
        }
    }

    override suspend fun updateZadanie(
        nazwa: String,
        opis: String,
        wydarzenieId: String,
        userId: String
    ) {
        withContext(Dispatchers.IO){
            postgrest.from("lista_zadan").update({
                set("opis_zadania", opis)
            }) {
                filter {
                    and {
                        eq("wydarzenieuuid", wydarzenieId)
                        eq("user_id", userId)
                        eq("nazwa_zadania", nazwa)
                    }

                }
            }
        }
    }

    override suspend fun completedZadanie(
        nazwa: String,
        czyWykonano: Boolean,
        wydarzenieId: String,
        userId: String
    ) {
        withContext(Dispatchers.IO){
            postgrest.from("lista_zadan").update({
                set("czy_wykonano", czyWykonano)
            }) {
                filter {
                    and {
                        eq("wydarzenieuuid", wydarzenieId)
                        eq("user_id", userId)
                        eq("nazwa_zadania", nazwa)
                    }

                }
            }
        }
    }

}