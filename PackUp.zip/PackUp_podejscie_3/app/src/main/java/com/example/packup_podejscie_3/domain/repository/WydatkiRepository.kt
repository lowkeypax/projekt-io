package com.example.packup_podejscie_3.domain.repository

import com.example.packup_podejscie_3.data.dto.Lista_zadanDto
import com.example.packup_podejscie_3.data.dto.WydatkiDto
import com.example.packup_podejscie_3.domain.model.Wydatki

interface WydatkiRepository {
    suspend fun createWydatek(wydatki: Wydatki): Boolean
    suspend fun getWydatki(wydarzenieId: String): List<WydatkiDto>
    suspend fun getWydatek(nazwaPrzedmiotu: String, wydarzenieId: String, userId: String): WydatkiDto
    suspend fun deleteWydatek(nazwaPrzedmiotu: String, wydarzenieId: String, userId: String)
    suspend fun updateWydatek(
        nazwaPrzedmiotu: String, kwota: Double, wydarzenieId: String, userId: String
    )

}