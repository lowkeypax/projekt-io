package com.example.packup_podejscie_3.data.dto

import com.example.packup_podejscie_3.domain.model.Ogloszenie
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import java.util.UUID

@Serializable
data class OgloszenieDto(
    @SerialName("Nazwa_ogloszenia")
    val nazwa: String,

    @SerialName("Opis_ogloszenia")
    val opis: String? = null,

    @SerialName("WydarzenieUUID")
    val wydarzenieId: String
)
