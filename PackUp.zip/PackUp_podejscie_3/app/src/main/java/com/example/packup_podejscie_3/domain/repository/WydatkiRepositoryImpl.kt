package com.example.packup_podejscie_3.domain.repository

import com.example.packup_podejscie_3.data.dto.Lista_zadanDto
import com.example.packup_podejscie_3.data.dto.WydatkiDto
import com.example.packup_podejscie_3.domain.model.Wydatki
import io.github.jan.supabase.postgrest.Postgrest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.lang.Exception
import javax.inject.Inject

class WydatkiRepositoryImpl @Inject constructor(
    private val postgrest: Postgrest
) : WydatkiRepository{
    override suspend fun createWydatek(wydatki: Wydatki): Boolean {
        return try{
            withContext(Dispatchers.IO) {
                val wydatkiDto = WydatkiDto(
                    nazwaPrzedmiotu = wydatki.nazwaPrzedmiotu,
                    wydarzenieId = wydatki.wydarzenieId,
                    userId = wydatki.userId,
                    kwota = wydatki.kwota
                )
                postgrest.from("wydatki").insert(wydatkiDto)
                true
            }
            true
        } catch (e: Exception){
            throw e
        }    }

    override suspend fun getWydatki(wydarzenieId: String): List<WydatkiDto> {
        return withContext(Dispatchers.IO){
            postgrest.from("wydatki").select {
                filter {
                    eq("wydarzenieuuid", wydarzenieId)
                }
            }.decodeList<WydatkiDto>()

        }
    }

    override suspend fun getWydatek(nazwaPrzedmiotu: String, wydarzenieId: String, userId: String): WydatkiDto {
        return withContext(Dispatchers.IO){
            postgrest.from("wydatki").select {
                filter {
                    and {
                        eq("nazwa_przedmiotu", nazwaPrzedmiotu)
                        eq("wydarzenieuuid", wydarzenieId)
                        eq("user_id", userId)
                    }
                }
            }.decodeSingle<WydatkiDto>()
        }
    }

    override suspend fun deleteWydatek(
        nazwaPrzedmiotu: String,
        wydarzenieId: String,
        userId: String
    ) {
        return withContext(Dispatchers.IO){
            postgrest.from("wydatki").delete {
                filter {
                    and {
                        eq("nazwa_zadania", nazwaPrzedmiotu)
                        eq("wydarzenieuuid", wydarzenieId)
                        eq("user_id", userId)
                    }
                }
            }
        }
    }

    override suspend fun updateWydatek(
        nazwaPrzedmiotu: String,
        kwota: Double,
        wydarzenieId: String,
        userId: String
    ) {
        withContext(Dispatchers.IO){
            postgrest.from("wydatki").update({
                set("kwota", kwota)
            }) {
                filter {
                    and {
                        eq("wydarzenieuuid", wydarzenieId)
                        eq("user_id", userId)
                        eq("nazwa_przedmiotu", nazwaPrzedmiotu)
                    }

                }
            }
        }
    }

}