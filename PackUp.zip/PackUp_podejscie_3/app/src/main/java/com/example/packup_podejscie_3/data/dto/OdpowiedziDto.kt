package com.example.packup_podejscie_3.data.dto

import com.example.packup_podejscie_3.domain.model.Odpowiedzi
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import java.util.UUID

@Serializable
data class OdpowiedziDto(
    @SerialName("ID")
    val id: String? = null,

    @SerialName("Odpowiedz")
    val odpowiedz: String,

    @SerialName("liczba_glosow")
    val liczbaGlosow: Int? = null,

    @SerialName("ankietauuid")
    val ankietaId: String
)
