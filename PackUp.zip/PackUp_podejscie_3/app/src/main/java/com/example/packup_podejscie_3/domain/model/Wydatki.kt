package com.example.packup_podejscie_3.domain.model

data class Wydatki(
    val nazwaPrzedmiotu: String,
    val kwota: Double,
    val wydarzenieId: String,
    val userId: String
)