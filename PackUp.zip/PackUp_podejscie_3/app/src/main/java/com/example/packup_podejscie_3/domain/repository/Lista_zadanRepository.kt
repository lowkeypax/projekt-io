package com.example.packup_podejscie_3.domain.repository

import com.example.packup_podejscie_3.data.dto.Lista_zadanDto
import com.example.packup_podejscie_3.domain.model.Lista_zadan


interface Lista_zadanRepository {
    suspend fun createZadanie(lista_zadan: Lista_zadan): Boolean
    suspend fun getLista_zadan(wydarzenieId: String): List<Lista_zadanDto>
    suspend fun getZadanie(nazwa: String, wydarzenieId: String, userId: String): Lista_zadanDto
    suspend fun deleteZadanie(nazwa: String, wydarzenieId: String, userId: String)
    suspend fun updateZadanie(
        nazwa: String, opis: String, wydarzenieId: String, userId: String
    )
    suspend fun completedZadanie(
        nazwa: String, czyWykonano: Boolean, wydarzenieId: String, userId: String
    )
}