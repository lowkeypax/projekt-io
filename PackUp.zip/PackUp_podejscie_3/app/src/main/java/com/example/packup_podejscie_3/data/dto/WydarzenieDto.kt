package com.example.packup_podejscie_3.data.dto

import com.example.packup_podejscie_3.domain.model.Wydarzenie
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.datetime.LocalDate
import java.util.UUID


@Serializable
data class WydarzenieDto(

    @SerialName("Nazwa_wydarzenia")
    val nazwa: String,

    @SerialName("Data_rozpoczecia")
    val data_rozpoczecia: String, // or LocalDate as custom type

    @SerialName("Data_zakonczenia")
    val data_zakonczenia: String,

    @SerialName("Opis_wydarzenia")
    val opis_wydarzenia: String? = null,

    @SerialName("WydarzenieUUID")
    val id: String? = null,
)




