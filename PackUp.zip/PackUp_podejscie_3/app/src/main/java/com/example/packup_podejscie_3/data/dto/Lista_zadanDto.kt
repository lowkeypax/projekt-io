package com.example.packup_podejscie_3.data.dto

import com.example.packup_podejscie_3.domain.model.Lista_zadan
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import java.util.UUID

@Serializable
data class Lista_zadanDto(
    @SerialName("Nazwa_zadania")
    val nazwa: String,

    @SerialName("Opis_zadania")
    val opis: String? = null,

    @SerialName("Czy_wykonano")
    val czyWykonano: Boolean = false,

    @SerialName("WydarzenieUUID")
    val wydarzenieId: String,

    @SerialName("user_id")
    val userId: String
)
