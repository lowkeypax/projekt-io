package com.example.packup_podejscie_3.domain.repository

import com.example.packup_podejscie_3.data.dto.AnkietyDto
import com.example.packup_podejscie_3.data.dto.OgloszenieDto
import com.example.packup_podejscie_3.domain.model.Ogloszenie
import io.github.jan.supabase.postgrest.Postgrest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject

class OgloszenieRepositoryImpl @Inject constructor(
    private val postgrest: Postgrest
): OgloszenieRepository{
    override suspend fun createOgloszenie(ogloszenie: Ogloszenie): Boolean {
        return try{
            withContext(Dispatchers.IO) {
                val ogloszenieDto = OgloszenieDto(
                    nazwa = ogloszenie.nazwa,
                    opis = ogloszenie.opis,
                    wydarzenieId = ogloszenie.wydarzenieId
                )
                postgrest.from("ogloszenie").insert(ogloszenieDto)
                true
            }
            true
        } catch (e: java.lang.Exception){
            throw e
        }
    }

    override suspend fun getOgloszenia(wydarzenieId: String): List<OgloszenieDto> {
        return withContext(Dispatchers.IO){
            postgrest.from("ogloszenie").select {
                filter {
                    eq("wydarzenieuuid", wydarzenieId)
                }
            }.decodeList<OgloszenieDto>()

        }
    }

    override suspend fun getOgloszenie(nazwa: String, wydarzenieId: String): OgloszenieDto {
        return withContext(Dispatchers.IO){
            postgrest.from("ogloszenie").select {
                filter {
                    and {
                        eq("wydarzenieuuid", wydarzenieId)
                        eq("nazwa_ogloszenia", nazwa)
                    }
                }
            }.decodeSingle<OgloszenieDto>()
        }
    }

    override suspend fun deleteOgloszenie(nazwa: String, wydarzenieId: String) {
        return withContext(Dispatchers.IO){
            postgrest.from("ogloszenie").delete {
                filter {
                    and {
                        eq("wydarzenieuuid", wydarzenieId)
                        eq("nazwa_ogloszenia", nazwa)
                    }
                }
            }
        }
    }

    override suspend fun updateOgloszenie(nazwa: String, opis: String, wydarzenieId: String) {
        withContext(Dispatchers.IO){
            postgrest.from("ogloszenie").update({
                set("opis_ogloszenia", opis)
            }) {
                filter {
                    and {
                        eq("wydarzenieuuid", wydarzenieId)
                        eq("nazwa_ogloszenia", nazwa)
                    }
                }
            }
        }
    }

}