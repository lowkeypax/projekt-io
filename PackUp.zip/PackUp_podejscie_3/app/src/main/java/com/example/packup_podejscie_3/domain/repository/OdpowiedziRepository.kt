package com.example.packup_podejscie_3.domain.repository

import com.example.packup_podejscie_3.data.dto.OdpowiedziDto
import com.example.packup_podejscie_3.domain.model.Odpowiedzi
import java.util.UUID

interface OdpowiedziRepository {
    suspend fun createOdpowiedzi(odpowiedzi: Odpowiedzi): Boolean
    suspend fun getOdpowiedzi(ankietaId: String): List<OdpowiedziDto>
    suspend fun getOdpowiedz(id: String): OdpowiedziDto
    suspend fun deleteOdpowiedz(id: String)
    suspend fun updateOdpowiedz(
        id: String,
        odpowiedz: String,
    )
    suspend fun updateLiczbaGlosow(
        id: String,
        liczbaGlosow: Int
    )
}