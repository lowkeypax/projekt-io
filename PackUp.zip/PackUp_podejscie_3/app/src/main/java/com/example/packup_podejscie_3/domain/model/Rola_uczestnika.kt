package com.example.packup_podejscie_3.domain.model

data class RolaUczestnika(
    val rola: String,
    val userId: String,
    val wydarzenieId: String
)