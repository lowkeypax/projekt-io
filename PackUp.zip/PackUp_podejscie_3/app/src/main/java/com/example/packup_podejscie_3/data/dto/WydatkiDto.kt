package com.example.packup_podejscie_3.data.dto

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class WydatkiDto(
    @SerialName("Nazwa_przedmiotu")
    val nazwaPrzedmiotu: String,

    @SerialName("Kwota")
    val kwota: Double,

    @SerialName("WydarzenieUUID")
    val wydarzenieId: String,

    @SerialName("user_id")
    val userId: String
)