package com.example.packup_podejscie_3.domain.model

import kotlinx.datetime.LocalDate
import java.util.UUID



data class Wydarzenie(
    val id: String,
    val nazwa: String,
    val data_rozpoczecia: String,
    val data_zakonczenia: String,
    val opis_wydarzenia: String?
)

