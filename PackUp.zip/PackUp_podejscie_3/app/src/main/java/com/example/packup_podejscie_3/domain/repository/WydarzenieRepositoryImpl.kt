package com.example.packup_podejscie_3.domain.repository




import com.example.packup_podejscie_3.data.dto.WydarzenieDto
import com.example.packup_podejscie_3.domain.model.Wydarzenie
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import com.example.packup_podejscie_3.domain.repository.WydarzenieRepository

import io.github.jan.supabase.postgrest.Postgrest
import io.github.jan.supabase.storage.Storage
import javax.inject.Inject

class WydarzenieRepositoryImpl @Inject constructor(
    private val postgrest: Postgrest,
    private val storage: Storage,
) : WydarzenieRepository {
    override suspend fun createWydarzenie(wydarzenie: Wydarzenie): Boolean {
        return try{
            withContext(Dispatchers.IO) {
                val wydarzenieDto = WydarzenieDto(
                    nazwa = wydarzenie.nazwa,
                    data_rozpoczecia = wydarzenie.data_rozpoczecia,
                    data_zakonczenia = wydarzenie.data_zakonczenia,
                    opis_wydarzenia = wydarzenie.opis_wydarzenia
                )
                postgrest.from("wydarzenie").insert(wydarzenieDto)
                true
            }
            true
        } catch (e: java.lang.Exception){
            throw e
        }
    }

    override suspend fun getWydarzenia(): List<WydarzenieDto> {
        return withContext(Dispatchers.IO){
            val result = postgrest.from("wydarzenie")
                .select().decodeList<WydarzenieDto>()
            result
        }
    }

    override suspend fun getWydarzenie(id: String): WydarzenieDto {
        return withContext(Dispatchers.IO){
            postgrest.from("wydarzenie").select {
                filter {
                    eq("wydarzenieuuid", id)
                }
            }.decodeSingle<WydarzenieDto>()
        }
    }

    override suspend fun deleteWydarzenie(id: String) {
        return withContext(Dispatchers.IO){
            postgrest.from("wydarzenie").delete {
                filter {
                    eq("wydarzenieuuid", id)
                }
            }
        }
    }

    override suspend fun updateWydarzenie(
        id: String,
        nazwa: String,
        data_rozpoczecia: String,
        data_zakonczenia: String,
        opis_wydarzenia: String?
    ) {
        withContext(Dispatchers.IO){
            postgrest.from("wydarzenie").update({
                set("nazwa_wydarzenia", nazwa)
                set("data_rozpoczecia", data_rozpoczecia)
                set("data_zakonczenia", data_zakonczenia)
                set("opis_wydarzenia", opis_wydarzenia)
            }) {
                filter {
                    eq("wydarzenieuuid", id)
                }
            }
        }
    }

}