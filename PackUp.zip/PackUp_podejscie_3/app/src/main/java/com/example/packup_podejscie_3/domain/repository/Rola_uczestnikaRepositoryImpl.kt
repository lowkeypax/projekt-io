package com.example.packup_podejscie_3.domain.repository

import com.example.packup_podejscie_3.data.dto.OgloszenieDto
import com.example.packup_podejscie_3.data.dto.RolaUczestnikaDto
import com.example.packup_podejscie_3.domain.model.RolaUczestnika
import io.github.jan.supabase.postgrest.Postgrest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject

class Rola_uczestnikaRepositoryImpl @Inject constructor(
    private val postgrest: Postgrest
) : Rola_uczestnikaRepository{
    override suspend fun createRola_uczestnika(rolaUczestnika: RolaUczestnika): Boolean {
        return try{
            withContext(Dispatchers.IO) {
                val rolaUczestnika = RolaUczestnikaDto(
                    rola = rolaUczestnika.rola,
                    userId = rolaUczestnika.userId,
                    wydarzenieId = rolaUczestnika.wydarzenieId
                )
                postgrest.from("rola_uczestnika").insert(rolaUczestnika)
                true
            }
            true
        } catch (e: java.lang.Exception){
            throw e
        }
    }

    override suspend fun getRole_uczestnikow(wydarzenieId: String): List<RolaUczestnikaDto> {
        return withContext(Dispatchers.IO){
            postgrest.from("rola_uczestnika").select {
                filter {
                    eq("wydarzenieuuid", wydarzenieId)
                }
            }.decodeList<RolaUczestnikaDto>()

        }
    }

    override suspend fun getRola_uczestnika(
        userId: String,
        wydarzenieId: String
    ): RolaUczestnikaDto {
        return withContext(Dispatchers.IO){
            postgrest.from("rola_uczestnika").select {
                filter {
                    and {
                        eq("wydarzenieuuid", wydarzenieId)
                        eq("user_id", userId)
                    }
                }
            }.decodeSingle<RolaUczestnikaDto>()
        }
    }

    override suspend fun deleteRola_uczestnika(userId: String, wydarzenieId: String) {
        return withContext(Dispatchers.IO){
            postgrest.from("rola_uczestnika").delete {
                filter {
                    and {
                        eq("wydarzenieuuid", wydarzenieId)
                        eq("user_id", userId)
                    }
                }
            }
        }
    }

    override suspend fun updateRola_uczestnika(userId: String, rola: String, wydarzenieId: String) {
        withContext(Dispatchers.IO){
            postgrest.from("rola_uczestnika").update({
                set("rola", rola)
            }) {
                filter {
                    and {
                        eq("wydarzenieuuid", wydarzenieId)
                        eq("user_id", userId)
                    }
                }
            }
        }
    }

}