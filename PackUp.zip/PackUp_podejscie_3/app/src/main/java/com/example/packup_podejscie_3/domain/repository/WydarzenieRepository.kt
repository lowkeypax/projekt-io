package com.example.packup_podejscie_3.domain.repository

import com.example.packup_podejscie_3.data.dto.WydarzenieDto
import com.example.packup_podejscie_3.domain.model.Wydarzenie


interface WydarzenieRepository {
    suspend fun createWydarzenie(wydarzenie: Wydarzenie): Boolean
    suspend fun getWydarzenia(): List<WydarzenieDto>
    suspend fun getWydarzenie(id: String): WydarzenieDto
    suspend fun deleteWydarzenie(id: String)
    suspend fun updateWydarzenie(
        id: String, nazwa: String, data_rozpoczecia: String, data_zakonczenia: String, opis_wydarzenia: String?
    )
}
