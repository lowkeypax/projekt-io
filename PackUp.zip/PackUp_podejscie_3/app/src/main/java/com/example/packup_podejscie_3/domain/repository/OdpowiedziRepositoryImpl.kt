package com.example.packup_podejscie_3.domain.repository

import com.example.packup_podejscie_3.data.dto.OdpowiedziDto
import com.example.packup_podejscie_3.domain.model.Odpowiedzi
import io.github.jan.supabase.postgrest.Postgrest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.lang.Exception
import javax.inject.Inject

class OdpowiedziRepositoryImpl @Inject constructor(
    private val postgrest: Postgrest,
) : OdpowiedziRepository {



    override suspend fun createOdpowiedzi(odpowiedzi: Odpowiedzi): Boolean {
        return try{
            withContext(Dispatchers.IO) {
                val odpowiedziDto = OdpowiedziDto(
                    ankietaId = odpowiedzi.ankietaId,
                    odpowiedz = odpowiedzi.odpowiedz
                )
                postgrest.from("odpowiedzi").insert(odpowiedziDto)
                true
            }
            true
        } catch (e: Exception){
            throw e
        }
    }

    override suspend fun getOdpowiedzi(ankietaId: String): List<OdpowiedziDto> {
        return withContext(Dispatchers.IO){
            postgrest.from("odpowiedzi").select {
                filter {
                    eq("ankietauuid", ankietaId)
                }
            }.decodeList<OdpowiedziDto>()

        }
    }

    override suspend fun getOdpowiedz(id: String): OdpowiedziDto {
        return withContext(Dispatchers.IO){
            postgrest.from("odpowiedzi").select {
                filter {
                    eq("id", id)
                }
            }.decodeSingle<OdpowiedziDto>()
        }
    }

    override suspend fun deleteOdpowiedz(id: String) {
        return withContext(Dispatchers.IO){
            postgrest.from("ankiety").delete {
                filter {
                    eq("id", id)
                }
            }
        }
    }

    override suspend fun updateOdpowiedz(id: String, odpowiedz: String) {
        withContext(Dispatchers.IO){
            postgrest.from("odpowiedzi").update({
                set("odpowiedz", odpowiedz)
            }) {
                filter {
                    eq("id", id)
                }
            }
        }
    }

    override suspend fun updateLiczbaGlosow(id: String, liczbaGlosow: Int) {
        withContext(Dispatchers.IO){
            postgrest.from("odpowiedzi").update({
                set("liczba_glosow", liczbaGlosow)
            }){
                filter {
                    eq("id", id)
                }
            }
        }
    }


}