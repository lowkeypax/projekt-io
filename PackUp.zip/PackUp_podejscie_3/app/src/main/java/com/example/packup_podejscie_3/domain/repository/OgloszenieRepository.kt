package com.example.packup_podejscie_3.domain.repository

import com.example.packup_podejscie_3.data.dto.OgloszenieDto
import com.example.packup_podejscie_3.domain.model.Ogloszenie

interface OgloszenieRepository {
    suspend fun createOgloszenie(ogloszenie: Ogloszenie): Boolean
    suspend fun getOgloszenia(wydarzenieId: String): List<OgloszenieDto>
    suspend fun getOgloszenie(nazwa: String, wydarzenieId: String): OgloszenieDto
    suspend fun deleteOgloszenie(nazwa: String, wydarzenieId: String)
    suspend fun updateOgloszenie(
        nazwa: String, opis: String, wydarzenieId: String
    )
}